#!/bin/sh

components="server"

function printUsage() {
cat 1>&2 <<EOT

usage: $0 {status|start|stop|restart} [ component ]

  status    Returns the status of the system or a single component.
  start     Starts the system or a single component.
  stop      Stops the system or a single component.
  restart   Restarts the system or a single component.

EOT

    echo -n "Components: " $components
    echo
}

CMP_NEXT_PACKAGES="/opt/cmpnext/packages"
cd $CMP_NEXT_PACKAGES

CMP_NEXT_JRE_DIRECTORY=`ls -d ibm*`/jre
export JAVA_HOME=$CMP_NEXT_PACKAGES/$CMP_NEXT_JRE_DIRECTORY

pid="0"

function serverStatus() {
    silent=$1

    pid=`ps -ef | grep "cmp-server.*\.jar " | grep -v "grep"  | head -n 1 | awk '{print $2}' 2>>/dev/null`

    if [ -z "$pid" ];
    then
        if [ "$silent" != "true" ]
        then
            echo "cmp-server is not up and running">&2
        fi
        pid=0
    else
        if [ "$silent" != "true" ]
        then
            echo "cmp-server is running with pid: " $pid >&2
        fi
    fi
}

function serverStop() {
    serverStatus true
    if [ "$pid" != "0" ]
    then
        kill -9 $pid
        echo "cmp-server is stopped"
    else
        echo "cmp-server is not up and running"
    fi
}

function serverStart() {
    serverStatus true
    if [ "$pid" = "0" ]
    then
        loaderPath=lib/,../app/
        cscmodlib=lib/CscMod-Factory.jar,lib/CscMod-KeyHost.jar,lib/CscMod-Utilities.jar
        $CMP_NEXT_JRE_DIRECTORY/bin/java -DCscMod.path=$cscmodlib -Djsse.enableSNIExtension=false -Dloader.path=$loaderPath -Dspring.profiles.active=production -jar ../app/cmp-server*.jar --server.ssl.key-store=file:../app/cmpKeyStore.jks --server.ssl.temp-key-store=file:../app/tempCmpKeyStore.jks --server.ssl.trust-store=file:../app/cmpTrustStore.jks --spring.config.location=file:../app/application.yml > /dev/null &
        echo "cmp-server is started"
    else
        echo "cmp-server is already running"
    fi

    cmpnc=`crontab -l |grep rmFolders |wc -l`
    if [ "$cmpnc" -eq "1" ]
    then
            echo "cron job found, do nothing"
    else
            (crontab -l 2>/dev/null; echo "0 1 * * * /opt/cmpnext/scripts/rmFolders") | crontab -
    fi

}

function status() {
    case $1 in
    server)
        serverStatus
        ;;
    esac
}

function stop() {
    case $1 in
    server)
        serverStop
        ;;
    esac
}

function start() {
    case $1 in
    server)
        serverStart
        ;;
    esac
}

## check arguments begin ----------------

case $1 in
    status|start|stop|restart)

    if [ "$2" != "" ]
    then
        FOUND="false"
        for i in $components
        do
           if [ "$2" = "$i" ]
           then
                FOUND="true"
                break
           fi
        done
        if [ "$FOUND" = "false" ]
        then
            printUsage
            echo -n $2

        fi
    fi
esac

case $1 in
    start)
        if [ "$2" = "" ]
        then
            for comp in $components
            do
              start $comp
            done
        else
            start $2
        fi
        ;;

    stop)
        if [ "$2" = "" ]
        then
            for comp in $components
            do
              stop $comp
            done
        else
            stop $2
        fi
        ;;

    restart)
        if [ "$2" = "" ]
        then
            for comp in $components
            do
              stop $comp
              echo
              start $comp
            done
        else
            stop $2
        fi
        ;;

    status)
        if [ "$2" = "" ]
        then
        for comp in $components
        do
          status $comp
        done
        else
            status $2
        fi
        ;;

        *)
            echo "Usage: $0 {start|stop|status|restart} {server}"
            exit 1
            ;;
esac
